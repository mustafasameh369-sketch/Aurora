# Aurora cislunar physics model

## What is now integrated

For lunar missions selecting **Near-Rectilinear Halo Orbit (NRHO)** or the **Earth–Moon L2 southern halo** while the mission target is the Moon, Aurora now computes the visible trajectory numerically with the Circular Restricted Three-Body Problem (CR3BP), rather than using a hand-drawn ellipse or fixed sinusoid.

The model uses the Earth–Moon barycentric rotating frame. Earth and Moon move on circular primary orbits; the spacecraft is treated as a negligible-mass body. The acceleration contains point-mass gravity, Coriolis terms and the centrifugal term. Integration uses an adaptive Dormand–Prince 5(4) Runge–Kutta method. Aurora monitors the Jacobi integral, closes the reference trajectory over its stated normalized period, and uses the sampled numerical states to build the 3D path and orient the spacecraft along its velocity tangent.

### Constants and normalization

| Parameter | Value |
|---|---:|
| Earth GM (DE440) | 398600.435507 km³/s² |
| Moon GM (DE440) | 4902.800118 km³/s² |
| Mean Earth–Moon distance used for normalization | 384400 km |
| Moon mean radius used for range reporting | 1737.4 km |
| CR3BP mass parameter μ | 0.012150584394709708 |
| Derived time unit | 375190.2619 s (about 4.34248 days) |

The model constants are based on JPL's published astrodynamic parameters and the standard mean Earth–Moon distance/radius values listed in the project's source comments. The game calculates the mass parameter and time unit from these constants at runtime.

## Reference orbits and validation

### Gateway-like 9:2 southern L2 NRHO

Aurora propagates a published normalized initial state for a southern L2 9:2 NRHO example. The resulting numerical orbit in the current DE440-based scale is approximately:

- Period: **6.55395 days**.
- Lunar perilune radius: **3226.5 km**.
- Maximum lunar range (apolune for this reference): **71173 km**.
- Jacobi integral maximum drift in the sampled run: approximately **1.5 × 10⁻¹¹**.
- State closure error after one normalized period: approximately **1.0 × 10⁻⁷**.

NASA's Gateway PPE reference trajectory describes a 9:2 southern L2 NRHO with an approximately 6.56-day period, a perilune radius range of 3196–3557 km, and an apolune near 70,000 km. A more detailed NASA orbit-parameter paper reports an apolune range of 70,005–71,849 km with a mean of 71,100 km, and a perilune range of 3,195–3,557 km. Aurora's computed perilune (3226.5 km) and apolune (71173 km) both fall within those published ranges, and the period is close to the 6.56-day mean. This is a calibration/consistency check, not proof that the displayed trajectory is NASA's mission ephemeris.

### Earth–Moon L2 southern halo reference

A second published southern L2 halo initial state is numerically integrated as a distinct, larger-amplitude family example. With Aurora's current JPL-based time normalization, its displayed period is about **12.52 days**. The cited publication reports a dimensional period using its own dimensional constants; the difference is why Aurora explicitly documents the constants and recomputes the dimensional period instead of silently copying the publication's rounded value.

## Important physical limitations

This is a substantially more physical model than a stylized orbit path, but it is not a precision mission-design propagator. Current limitations:

- Circular Restricted Three-Body Problem only: Earth and Moon are modeled as point masses on circular primary orbits.
- No solar third-body perturbation, Earth/Moon gravity harmonics (J2 and higher), solar radiation pressure, tides, or eclipsing-related thermal/power coupling in the equations of motion.
- No maneuver execution, finite-thrust guidance, orbit determination, covariance, station-keeping strategy, or navigation filter.
- The reference initial states are literature examples, not a downloaded NASA SPK trajectory or a mission-certified Gateway ephemeris.
- The 3D view compresses the Moon-centered display scale for legibility. The trajectory calculations remain in normalized physical CR3BP coordinates; visual scene distances are deliberately compressed and labeled as such. The spacecraft animation runs at an accelerated presentation rate (one visual orbit is shown in seconds) and is not a real-time mission clock; the period shown in the orbit card is the physically scaled model period.
- The rest of Aurora's spacecraft mass, component cost, power, communications and event scoring remain educational game-balance models.

Do not use Aurora to plan or certify an actual spacecraft trajectory.

## Sources

1. NASA, *Power and Propulsion Element (PPE) Spacecraft Reference Trajectory*, NASA/TM-2020-220481 (March 2020). The Gateway reference NRHO characteristics are summarized in Table 3-1 and the accompanying orbit discussion. [NASA NTRS PDF](https://ntrs.nasa.gov/api/citations/20200002143/downloads/20200002143.pdf?attachment=true).
2. NASA, *Phase Control and Eclipse Avoidance for the Gateway NRHO* (NASA NTRS 20200000733). Reports the 15-year Gateway NRHO min/mean/max period, perilune and apolune values used for the finer range check. [NASA NTRS PDF](https://ntrs.nasa.gov/api/citations/20200000733/downloads/20200000733.pdf?attachment=true).
3. JPL Solar System Dynamics, *Astrodynamic Parameters*. DE440 gravitational parameters used for Earth and Moon. [JPL reference](https://ssd.jpl.nasa.gov/astro_par.html).
4. *Transfers Orbit Design from Lunar Frozen Orbit to Near Rectilinear Halo Orbit*, Journal of Deep Space Exploration, DOI: 10.3724/j.issn.2096-9287.2026.20250106. Source for the normalized 9:2 NRHO reference state used for the educational integration. [Article record](https://www.sciengine.com/JDSE/doi/10.3724/j.issn.2096-9287.2026.20250106).
5. Peterson et al., *Local Orbital Elements Around Periodic Orbits*, AAS 26-791 (2026 preprint). Source for the second southern L2 halo example state. [Preprint record](https://www.researchgate.net/publication/408580099_AAS_26-791_Local_Orbital_Elements_Around_Periodic_Orbits).
6. JPL, *Horizons API* and NAIF SPICE documentation are listed as possible future sources for higher-fidelity ephemeris and trajectory work; Aurora does **not** currently load live Horizons data or a Gateway SPK kernel. [Horizons API](https://ssd-api.jpl.nasa.gov/doc/horizons.html) · [NAIF SPICE](https://naif.jpl.nasa.gov/naif/).
