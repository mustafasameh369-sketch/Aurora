# NASA Space Apps 2026 — submission readiness gates

This is a project engineering checklist, not a ruling by NASA or the local event organizers.

## 1. Pre-existing work and challenge eligibility

Before submission, compare the project's actual development timeline with the current challenge rules. Describe accurately which components, code, documentation, and assets existed before the official challenge period and which work was completed during it. Do not describe previously completed work as having been created during the official event.

A November 11, 2026 reply in discussion #1924 is marked **Navigator answered**, not **GO Team answered**. It says previous work/open-source code may be reused when credited and not built specifically for NASA Space Apps, while challenge-specific development must occur during the official hackathon. This is relevant guidance but is not a direct GO Team ruling. If the rules do not clearly address the project's development timeline, ask the GO Team or local organizer for written clarification.

Sources:
- [Navigator answer, discussion #1924 (not labelled GO Team)](https://github.com/nasa/spaceapps/discussions/1924)
- [NASA Space Apps 2026 participant page](https://www.spaceappschallenge.org/2026/)

## 2. NASA resource listed for this challenge — strong candidate integrated; organizer confirmation still prudent

The GO Team states that Global Award eligibility requires meaningful use of at least one NASA data source from the selected challenge's Resources tab, and that all sources, resources and tools must be listed in the submission. The HackAthlone local-event challenge page lists nine resources (eight NASA and one CSA) and explicitly places **Concept Maturity Levels (CMLs)** under “NASA data and resources”. The page also states that the official NASA challenge page is the final authority; the official page could not be directly accessed in this review, so compare the account Resources tab before submitting. Its link opens the JPL Open Repository record **"Space mission concept development using concept maturity levels"** (Version 2.0, persistent identifier `hdl:2014/44299`). JPL Dataverse labels the record as a dataset, provides a public PDF, and records a CC0 1.0 license.

Aurora uses the CML 1–4 framework as the mission-concept maturity progression shown to players. This is a stronger challenge-resource link than the Gateway/DE440 scientific references, because the CML resource itself appears in the challenge resource list. However, its payload is a framework paper rather than a conventional observational measurement dataset. The published rule says "NASA data source" but does not explain whether a framework paper hosted as a JPL Dataverse dataset qualifies. Treat CML as a **strong candidate, not a guaranteed ruling**, and ask the GO Team/local organizer to confirm the interpretation in writing if Global Awards eligibility matters.

Sources:
- [GO Team eligibility and citation guidance, discussion #1827](https://github.com/nasa/spaceapps/discussions/1827)
- [Challenge resource list reproduced by HackAthlone (local NASA Space Apps event site)](https://hackathlone.com/challenges/space-mission-design-game)
- [JPL Open Repository CML record — dataset, Version 2.0, CC0 1.0](https://dataverse.jpl.nasa.gov/dataset.xhtml?persistentId=hdl%3A2014%2F44299)
- [NASA Gateway PPE reference trajectory](https://ntrs.nasa.gov/api/citations/20200002143/downloads/20200002143.pdf)
- [JPL DE440 astrodynamic parameters](https://ssd.jpl.nasa.gov/astro_par.html)

## Remaining delivery checklist

- [ ] Confirm in writing how the challenge rules treat work completed before the official challenge period, if the rules are unclear.
- [ ] Verify the exact official challenge Resources tab and demonstrate one qualifying NASA data source in the game.
- [ ] Add the public Aurora demo URL and final source/repository URL to the team submission.
- [ ] Capture genuine game screenshots on a real device; do not use generated mockups or screenshots that do not represent the submitted build.
- [ ] Record a public demo video of 30 seconds or less, or prepare a slide deck of no more than seven slides, per current submission guidance.
- [ ] List all source code, APIs/datasets, third-party libraries, fonts, art packs, documentation and AI/SI tools used.
- [ ] Open all public links in a private/incognito browser to ensure judges can access them without signing in.
- [ ] Complete and submit the project from the team's NASA Space Apps project page before the deadline shown for the team owner's local event.

The 2026 participant site says submission closes on November 15, 2026 at 11:59 PM local time for the event. Confirm the timezone shown on the team's page.

## Detailed phone and resource verification

- Android physical-device procedure and required evidence: [`ANDROID-REAL-DEVICE-QA-AR.md`](ANDROID-REAL-DEVICE-QA-AR.md).
- NASA challenge resource cross-check and unresolved qualifying-source gate: [`NASA-RESOURCES-VERIFY-AR.md`](NASA-RESOURCES-VERIFY-AR.md).
