# نشر Aurora وتهيئة اللعب الجماعي — دليل عربي

> يمكنك تنفيذ الخطوات من الهاتف عبر متصفح Chrome، لكن ستحتاج إلى حساب Cloudflare ومستودع GitHub. لا ترسل رمز API أو كلمة مرور إلى المحادثة.

## ما الذي سيُفعّل بعد النشر؟

- استضافة ملفات اللعبة على Cloudflare Workers Static Assets.
- واجهة `/api/health`.
- لوحة المتصدرين وتخزين النتائج في D1.
- غرف اللعب عبر الإنترنت عبر Durable Objects وWebSockets، حتى أربعة مقاعد: Commander وEngineering وScience وOperations.

## 1) إنشاء D1 تلقائيًا

لم تعد بحاجة إلى إنشاء قاعدة البيانات يدويًا أو تعديل `wrangler.jsonc` على الهاتف. عند تشغيل Workflow النشر، ينفّذ `scripts/ensure-d1.mjs` طلبًا إلى Cloudflare API: يبحث عن قاعدة `aurora-space-mission` في حساب الفريق، ويعيد استخدام الموجودة إن عثر عليها، أو ينشئها إن لم تكن موجودة، ثم يكتب UUID في نسخة إعداد Wrangler داخل مهمة GitHub Actions. يختار الإنشاء موقع `eeur` كإشارة جغرافية قريبة من مصر/شرق أوروبا. ولا يعدّل أي قاعدة بيانات أخرى غير مخصّصة لهذا المشروع.

يمكنك إنشاء D1 يدويًا من Cloudflare Dashboard بدلًا من ذلك، لكن استخدم الاسم نفسه `aurora-space-mission` حتى يعثر عليها Workflow ويعيد استخدامها.

## 2) إضافة أسرار النشر إلى GitHub

من مستودع Aurora على GitHub:

1. افتح **Settings → Secrets and variables → Actions**.
2. أضف Secret باسم `CLOUDFLARE_API_TOKEN` باستخدام API Token بصلاحيات **D1 Write** لإنشاء قاعدة D1 وتطبيق الهجرات، و**Workers Admin** على مستوى منتج Workers لأول نشر لأن Worker جديد سيُنشأ. بعد نجاح أول نشر يمكن استبدال الصلاحية بـ **Workers Editor** للنشر على Worker الموجود. صلاحيات Workers الحديثة تستخدم أدوار Admin/Editor؛ لا تعتمد على أسماء الصلاحيات القديمة وحدها.
3. أضف Secret باسم `CLOUDFLARE_ACCOUNT_ID` بقيمة Account ID الظاهرة في لوحة Cloudflare.
4. لأن هذا هو أول نشر وقد لا يكون Worker موجودًا، يحتاج الـ Token إلى دور **Workers Admin** على مستوى منتج Workers في حساب الفريق؛ إنشاء Worker جديد يتطلب Admin. بعد نجاح النشر الأول، أنشئ Token جديدًا بدور **Workers Editor** على Worker `aurora-space-mission` (أو على مستوى منتج Workers) واستبدل Secret به للمرات التالية.
5. لا تضع هذه القيم داخل ملفات المشروع أو في محادثة عامة ولا ترسل Token لأي شخص.

## 3) تشغيل النشر

1. افتح تبويب **Actions** في GitHub.
2. اختر workflow باسم **Deploy Aurora to Cloudflare**.
3. اضغط **Run workflow**.
4. قبل التشغيل، أدخل رابط Worker العام في حقل `worker_url` إن كان لديك الرابط (مثل `https://aurora-space-mission.<account-subdomain>.workers.dev`). في أول نشر يمكن تركه فارغًا، لكن اختبار الغرف البعيد سيتخطى.
5. ينشئ Workflow قاعدة D1 أو يعيد استخدام الموجودة، يربط UUID بإعداد Wrangler مؤقتًا، يشغّل الاختبارات، يطبق ملف الهجرة `migrations/0001_init.sql`، ثم ينشر Worker.
6. إذا أدخلت `worker_url`، يشغّل workflow تلقائيًا `test/api-smoke.mjs` للتحقق من health وD1 ولوحة النتائج وغرف Durable Objects ذات أربعة مقاعد عبر WebSocket. هذا اختبار آلي من CI لأربعة عملاء افتراضيين منفصلين؛ لا يساوي اختبارًا بشريًا على أربعة هواتف فعلية.
7. بعد أول نشر، انسخ رابط `workers.dev` من سجل خطوة Deploy Worker، ثم أعد تشغيل workflow وأدخله في `worker_url` لإجراء اختبار الاتصال البعيد.

إذا فشل إنشاء/العثور على D1، أو بقي `database_id` صفريًا، يوقف Workflow النشر قبل الاتصال بقاعدة غير معروفة.

## 4) التحقق بعد النشر

افتح `https://YOUR-WORKER-URL/api/health`. يجب أن تكون النتيجة شبيهة بـ:

```json
{"ok":true,"leaderboard":true,"rooms":true,"ready":true}
```

- `d1Configured: true` يعني أن ربط D1 موجود.
- `leaderboard: true` يعني أن جدول `scores` موجود ويمكن الاستعلام منه، وليس مجرد وجود binding.
- `rooms: true` يعني أن Durable Object binding موجود.
- `ready: true` يعني أن جدول النتائج وbinding الغرف موجودان؛ لكنه لا يغني عن اختبار إرسال نتيجة وفتح غرفة فعلية.

## 5) اختبار محلي للمطورين

على كمبيوتر يعمل عليه Node.js 20+:

```bash
npm ci
npm test
npm run db:migrate:local
npm run dev
```

في نافذة ثانية:

```bash
npm run test:smoke
```

يتحقق اختبار Smoke من صحة النقاط النهائية، إعادة حساب النقاط على الخادم، التخزين في D1، انضمام أربعة لاعبين بأدوار مختلفة، رفض اللاعب الخامس، مشاركة حالة Commander، والتصويت واستعادة المقعد برمز إعادة الاتصال. بعد النشر يمكن تشغيله من GitHub Actions بإدخال رابط Worker في `worker_url` أو يدويًا باستخدام `npm run test:smoke:remote -- https://YOUR-WORKER-URL`.

## ما لم يُنفذ تلقائيًا

لا يمكن إنشاء D1 أو نشر Worker إلى حساب الفريق من داخل هذا الأرشيف من دون صلاحية حساب Cloudflare ورموز الفريق. كما أن `npm run test:smoke` لم يُشغّل في بيئة إعداد هذا الإصدار لأن تثبيت Wrangler لم يكتمل؛ سكربت الاختبار موجود ويجب تشغيله بعد التثبيت أو عبر CI.

## ملاحظة الصلاحيات الحالية لدى Cloudflare

بحسب نموذج Cloudflare المحدث (سبتمبر 2026)، إنشاء Worker جديد يتطلب دور `Admin` على مستوى منتج Workers؛ نشر/تحديث Worker موجود يتطلب `Editor`. كما أن إنشاء D1 يتطلب `D1 Write`، وقائمة قواعد D1 تقبل `D1 Read` أو `D1 Write`. لذلك استخدم دور Admin للنشر الأول فقط، ثم قلّصه إلى Editor بعد وجود Worker.

مراجع: [Workers roles and permissions](https://developers.cloudflare.com/workers/authorization/workers/)؛ [Create D1 Database API](https://developers.cloudflare.com/api/resources/d1/subresources/database/methods/create/)؛ [List D1 Databases API](https://developers.cloudflare.com/api/resources/d1/subresources/database/methods/list/).
