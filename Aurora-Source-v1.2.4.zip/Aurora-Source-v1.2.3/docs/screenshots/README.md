# Aurora screenshot evidence

This directory intentionally contains no JPEG or PNG files yet.

Before official submission, capture the actual running Aurora build (not static mockups) on the target device. Recommended screens: title, mission selection, spacecraft builder, lunar launch/NRHO view, operations event, and final debrief. Keep the original unedited files and record the build commit/date.
