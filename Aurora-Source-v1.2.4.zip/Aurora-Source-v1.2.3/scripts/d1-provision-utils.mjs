const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function findNamedDatabase(payload, name) {
  const items = Array.isArray(payload)
    ? payload
    : Array.isArray(payload?.result)
      ? payload.result
      : Array.isArray(payload?.databases)
        ? payload.databases
        : [];
  return items.find((item) => (item?.name ?? item?.database_name) === name) ?? null;
}

export function updateWranglerDatabaseId(configText, name, databaseId) {
  if (!UUID_RE.test(databaseId) || databaseId === '00000000-0000-0000-0000-000000000000') {
    throw new Error('Cloudflare returned an invalid D1 database UUID.');
  }

  const targetEntry = /("database_name"\s*:\s*"([^"]+)"[\s\S]{0,300}?"database_id"\s*:\s*")[^"]+("\s*[,}])/g;
  let matches = 0;
  const updated = configText.replace(targetEntry, (whole, before, dbName, after) => {
    if (dbName !== name) return whole;
    matches += 1;
    return `${before}${databaseId}${after}`;
  });
  if (matches !== 1) {
    throw new Error(`Expected exactly one D1 binding named ${name}; found ${matches}.`);
  }
  return updated;
}
