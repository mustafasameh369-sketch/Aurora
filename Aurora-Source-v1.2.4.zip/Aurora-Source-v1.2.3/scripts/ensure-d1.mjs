import fs from 'node:fs';
import { findNamedDatabase, updateWranglerDatabaseId } from './d1-provision-utils.mjs';

const accountId = process.env.CLOUDFLARE_ACCOUNT_ID;
const apiToken = process.env.CLOUDFLARE_API_TOKEN;
const databaseName = 'aurora-space-mission';
if (!accountId || !apiToken) {
  console.error('Missing CLOUDFLARE_ACCOUNT_ID or CLOUDFLARE_API_TOKEN in the CI environment.');
  process.exit(1);
}

async function cloudflare(path, method = 'GET', body) {
  const response = await fetch(`https://api.cloudflare.com/client/v4${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${apiToken}`,
      'Content-Type': 'application/json'
    },
    ...(body ? { body: JSON.stringify(body) } : {})
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success !== true) {
    const details = (payload.errors || []).map((e) => e.message).filter(Boolean).join('; ');
    throw new Error(`Cloudflare D1 API ${method} failed (${response.status}): ${details || 'no API detail returned'}`);
  }
  return payload;
}

const endpoint = `/accounts/${encodeURIComponent(accountId)}/d1/database?name=${encodeURIComponent(databaseName)}`;
let list = await cloudflare(endpoint);
let database = findNamedDatabase(list, databaseName);
if (!database) {
  console.log(`Creating D1 database ${databaseName} in the team Cloudflare account...`);
  const created = await cloudflare(`/accounts/${encodeURIComponent(accountId)}/d1/database`, 'POST', {
    name: databaseName,
    primary_location_hint: 'eeur'
  });
  database = created.result;
}

const databaseId = database?.uuid;
if (!databaseId) throw new Error('Cloudflare API did not return a D1 UUID for aurora-space-mission.');
const configPath = new URL('../wrangler.jsonc', import.meta.url);
const configText = fs.readFileSync(configPath, 'utf8');
const updatedConfig = updateWranglerDatabaseId(configText, databaseName, databaseId);
fs.writeFileSync(configPath, updatedConfig);
console.log(`D1 ready: ${databaseName} (${databaseId}). Wrangler config updated for this deploy job.`);
