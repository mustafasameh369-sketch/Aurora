import fs from 'node:fs';

const config = fs.readFileSync(new URL('../wrangler.jsonc', import.meta.url), 'utf8');
const match = config.match(/"database_id"\s*:\s*"([^"]+)"/);
const id = match?.[1] ?? '';
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
if (!uuid.test(id) || id === '00000000-0000-0000-0000-000000000000') {
  console.error('\nAurora Cloudflare preflight failed: D1 database_id is still a placeholder.');
  console.error('Create a database with: npx wrangler d1 create aurora-space-mission');
  console.error('Copy the returned database_id into wrangler.jsonc, then run the remote migration and deploy.\n');
  process.exit(1);
}
console.log('Cloudflare preflight passed: D1 database_id is configured.');
