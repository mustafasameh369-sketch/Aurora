// Aurora orbital mechanics utilities: two-body Keplerian propagation for closed conic orbits.
// Halo/three-body and flyby trajectories are intentionally kept as explicit visual approximations.
const TAU = Math.PI * 2;
const finite = (v) => Number.isFinite(v);

export function solveKepler(meanAnomaly, eccentricity, tolerance = 1e-12) {
  if (!finite(meanAnomaly)) throw new TypeError('Mean anomaly must be finite.');
  if (!finite(eccentricity) || eccentricity < 0 || eccentricity >= 1) throw new RangeError('Elliptic eccentricity must be in [0, 1).');
  const M = ((meanAnomaly % TAU) + TAU * 1.5) % TAU - Math.PI;
  let E = eccentricity < 0.8 ? M : (M < 0 ? -Math.PI : Math.PI);
  for (let i = 0; i < 16; i++) {
    const f = E - eccentricity * Math.sin(E) - M;
    const fp = 1 - eccentricity * Math.cos(E);
    const delta = f / fp;
    E -= delta;
    if (Math.abs(delta) <= tolerance) return E;
  }
  // A monotonic bracketed solve is slower but robust near e → 1 and M → 0.
  let low = -Math.PI, high = Math.PI;
  for (let i = 0; i < 80; i++) {
    const mid = (low + high) / 2;
    const residual = mid - eccentricity * Math.sin(mid) - M;
    if (Math.abs(residual) <= tolerance || high - low <= tolerance) return mid;
    if (residual > 0) high = mid; else low = mid;
  }
  return (low + high) / 2;
}

function rotatePerifocal(x, y, inclination, raan, argumentOfPeriapsis) {
  const ci = Math.cos(inclination), si = Math.sin(inclination);
  const co = Math.cos(raan), so = Math.sin(raan);
  const cw = Math.cos(argumentOfPeriapsis), sw = Math.sin(argumentOfPeriapsis);
  const xw = cw * x - sw * y;
  const yw = sw * x + cw * y;
  return {
    x: co * xw - so * ci * yw,
    y: so * xw + co * ci * yw,
    z: si * yw
  };
}

/** Return the inertial position in the same distance unit as semiMajorAxis. */
export function keplerianPosition(elements, meanAnomaly) {
  const a = Number(elements?.semiMajorAxis);
  const e = Number(elements?.eccentricity ?? 0);
  if (!finite(a) || a <= 0) throw new RangeError('Semi-major axis must be positive and finite.');
  const E = solveKepler(meanAnomaly, e);
  const x = a * (Math.cos(E) - e);
  const y = a * Math.sqrt(1 - e * e) * Math.sin(E);
  const toRad = (v) => Number(v || 0) * Math.PI / 180;
  return rotatePerifocal(x, y, toRad(elements.inclinationDeg), toRad(elements.raanDeg), toRad(elements.argumentOfPeriapsisDeg));
}

/** Create a normalized-cycle position function suitable for deterministic scene animation. */
export function createKeplerOrbit(elements) {
  return (cycle) => {
    if (!finite(cycle)) throw new TypeError('Orbit cycle must be finite.');
    return keplerianPosition(elements, ((cycle % 1) + 1) % 1 * TAU);
  };
}

/** Two-body state propagation helper. Inputs use SI units; returns position (m) and velocity (m/s). */
export function propagateKepler(elements, elapsedSeconds, gravitationalParameter) {
  const a = Number(elements?.semiMajorAxis);
  const e = Number(elements?.eccentricity ?? 0);
  const mu = Number(gravitationalParameter);
  if (!finite(a) || a <= 0 || !finite(mu) || mu <= 0 || !finite(elapsedSeconds)) throw new RangeError('Valid semi-major axis, elapsed time and gravitational parameter are required.');
  if (!finite(e) || e < 0 || e >= 1) throw new RangeError('Elliptic eccentricity must be in [0, 1).');
  const n = Math.sqrt(mu / (a * a * a));
  const M0 = Number(elements.meanAnomalyDeg || 0) * Math.PI / 180;
  const E = solveKepler(M0 + n * elapsedSeconds, e);
  const den = 1 - e * Math.cos(E);
  const x = a * (Math.cos(E) - e);
  const y = a * Math.sqrt(1 - e * e) * Math.sin(E);
  const vx = -a * n * Math.sin(E) / den;
  const vy = a * n * Math.sqrt(1 - e * e) * Math.cos(E) / den;
  const angles = [elements.inclinationDeg, elements.raanDeg, elements.argumentOfPeriapsisDeg].map((v) => Number(v || 0));
  const rad = angles.map((v) => v * Math.PI / 180);
  return {
    position: rotatePerifocal(x, y, ...rad),
    velocity: rotatePerifocal(vx, vy, ...rad),
    meanMotion: n,
    period: TAU / n
  };
}
