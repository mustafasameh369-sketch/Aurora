// Aurora CR3BP cislunar dynamics.
// Model: Circular Restricted Three-Body Problem (Earth + Moon + negligible spacecraft)
// in the barycentric synodic rotating frame. Units are normalized by Earth-Moon
// separation and mean-motion time. This is a physically based educational model,
// not a high-fidelity ephemeris/flight-dynamics propagator.

export const EARTH_MOON = Object.freeze({
  earthGMKm3s2: 398600.435507,
  moonGMKm3s2: 4902.800118,
  separationKm: 384400,
  moonMeanRadiusKm: 1737.4,
  earthMeanRadiusKm: 6378.1363,
  mu: 4902.800118 / (398600.435507 + 4902.800118),
  timeUnitSeconds: Math.sqrt(384400 ** 3 / (398600.435507 + 4902.800118)),
});

const MU = EARTH_MOON.mu;
const LU_KM = EARTH_MOON.separationKm;
const TU_S = EARTH_MOON.timeUnitSeconds;
const DAY_S = 86400;
const finite = Number.isFinite;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

// Reference states are normalized CR3BP synodic states [x,y,z,vx,vy,vz].
// The first is a published southern L2 9:2 NRHO numerical example. The second
// is a published Earth-Moon L2 southern halo-orbit example. Both are integrated
// afresh by Aurora; trajectory points are not hand-drawn splines.
export const CR3BP_REFERENCE_ORBITS = Object.freeze({
  nrho: Object.freeze({
    id: 'nrho',
    name: 'Gateway-like southern L2 NRHO (9:2)',
    initialState: Object.freeze([1.0218813, 0, -0.18199999, 0, -0.10295079, 0]),
    periodTU: 1.5092635,
    periodDaysPublished: 6.56,
    expectedPeriluneKm: [3196, 3557],
    expectedApoluneKm: 70000,
    expectedMeanPeriluneKm: 3366,
    family: 'L2 southern · 9:2 lunar synodic resonance',
    stateSource: 'https://www.sciengine.com/JDSE/doi/10.3724/j.issn.2096-9287.2026.20250106',
  }),
  l2: Object.freeze({
    id: 'l2',
    name: 'Earth-Moon L2 southern halo reference orbit',
    initialState: Object.freeze([1.118728010172908, 0, -0.1879492221080791, 0, -0.2244436919332142, 0]),
    periodTU: 2.8827403879776115,
    sourceReportedPeriodDays: 12.778,
    sourceTimeUnitSeconds: 382981,
    family: 'L2 southern halo family',
    stateSource: 'https://www.researchgate.net/publication/408580099_AAS_26-791_Local_Orbital_Elements_Around_Periodic_Orbits',
  }),
});

export const NASA_GATEWAY_NRHO_REFERENCE = Object.freeze({
  mission: 'Gateway reference 9:2 southern L2 NRHO',
  referenceEpoch: '2020-01-02',
  referenceDurationYears: 15,
  averagePeriodDays: 6.56,
  meanPeriluneRadiusKm: 3366,
  periluneRadiusRangeKm: Object.freeze([3196, 3557]),
  apoluneRadiusKm: 71100,
  apoluneRadiusRangeKm: Object.freeze([70005, 71849]),
  source: 'https://ntrs.nasa.gov/api/citations/20200002143/downloads/20200002143.pdf?attachment=true',
});

/** CR3BP state derivative in normalized barycentric rotating coordinates. */
export function cr3bpDerivative(state, mu = MU) {
  if (!Array.isArray(state) || state.length !== 6 || !state.every(finite)) {
    throw new TypeError('CR3BP state must be six finite numbers [x,y,z,vx,vy,vz].');
  }
  if (!finite(mu) || mu <= 0 || mu >= 0.5) throw new RangeError('CR3BP mass parameter must be in (0, 0.5).');
  const [x, y, z, vx, vy, vz] = state;
  const dx1 = x + mu;
  const dx2 = x - 1 + mu;
  const r1sq = dx1 * dx1 + y * y + z * z;
  const r2sq = dx2 * dx2 + y * y + z * z;
  const r1 = Math.sqrt(r1sq);
  const r2 = Math.sqrt(r2sq);
  if (r1 < 1e-9 || r2 < 1e-9) throw new RangeError('Trajectory reached a primary-body singularity.');
  const invR13 = 1 / (r1sq * r1);
  const invR23 = 1 / (r2sq * r2);
  const ax = 2 * vy + x - (1 - mu) * dx1 * invR13 - mu * dx2 * invR23;
  const ay = -2 * vx + y - (1 - mu) * y * invR13 - mu * y * invR23;
  const az = -(1 - mu) * z * invR13 - mu * z * invR23;
  return [vx, vy, vz, ax, ay, az];
}

function combine(y, h, terms) {
  const out = y.slice();
  for (let j = 0; j < 6; j++) {
    let sum = 0;
    for (const [coefficient, k] of terms) sum += coefficient * k[j];
    out[j] += h * sum;
  }
  return out;
}

// Dormand-Prince 5(4), adaptive step-size integration.
function dopriStep(y, h, mu) {
  const f = (s) => cr3bpDerivative(s, mu);
  const k1 = f(y);
  const k2 = f(combine(y, h, [[1 / 5, k1]]));
  const k3 = f(combine(y, h, [[3 / 40, k1], [9 / 40, k2]]));
  const k4 = f(combine(y, h, [[44 / 45, k1], [-56 / 15, k2], [32 / 9, k3]]));
  const k5 = f(combine(y, h, [[19372 / 6561, k1], [-25360 / 2187, k2], [64448 / 6561, k3], [-212 / 729, k4]]));
  const k6 = f(combine(y, h, [[9017 / 3168, k1], [-355 / 33, k2], [46732 / 5247, k3], [49 / 176, k4], [-5103 / 18656, k5]]));
  const y5 = combine(y, h, [[35 / 384, k1], [500 / 1113, k3], [125 / 192, k4], [-2187 / 6784, k5], [11 / 84, k6]]);
  const k7 = f(y5);
  const y4 = combine(y, h, [[5179 / 57600, k1], [7571 / 16695, k3], [393 / 640, k4], [-92097 / 339200, k5], [187 / 2100, k6], [1 / 40, k7]]);
  return { y: y5, error: y5.map((v, i) => v - y4[i]) };
}

/** Integrate from t=0 to duration (normalized time) using adaptive DOPRI5. */
export function propagateCR3BP(initialState, duration, options = {}) {
  if (!Array.isArray(initialState) || initialState.length !== 6 || !initialState.every(finite)) {
    throw new TypeError('Initial state must contain six finite values.');
  }
  if (!finite(duration) || duration < 0) throw new RangeError('Duration must be finite and non-negative.');
  const mu = options.mu ?? MU;
  const relTol = options.relTol ?? 2e-11;
  const absTol = options.absTol ?? 2e-13;
  const maxStep = options.maxStep ?? 0.01;
  const minStep = options.minStep ?? 1e-12;
  const maxSteps = options.maxSteps ?? 500000;
  if (![mu, relTol, absTol, maxStep, minStep].every(finite) || mu <= 0 || mu >= 0.5 || relTol <= 0 || absTol <= 0 || maxStep <= 0 || minStep <= 0) {
    throw new RangeError('Invalid integration options.');
  }
  let state = initialState.slice();
  let t = 0;
  let h = Math.min(maxStep, duration || maxStep);
  let steps = 0;
  while (t < duration) {
    if (++steps > maxSteps) throw new Error('CR3BP integrator exceeded maxSteps.');
    h = Math.min(h, maxStep, duration - t);
    const trial = dopriStep(state, h, mu);
    let errorNorm = 0;
    for (let i = 0; i < 6; i++) {
      const scale = absTol + relTol * Math.max(Math.abs(state[i]), Math.abs(trial.y[i]));
      errorNorm = Math.max(errorNorm, Math.abs(trial.error[i]) / scale);
    }
    if (errorNorm <= 1) {
      state = trial.y;
      t += h;
    }
    const factor = errorNorm === 0 ? 5 : clamp(0.9 * Math.pow(1 / errorNorm, 0.2), 0.2, 5);
    h *= factor;
    if (h < minStep && t < duration) throw new Error('CR3BP integrator step underflow.');
  }
  return { state, elapsed: t, steps, jacobi: jacobiConstant(state, mu) };
}

/** Sample a published periodic reference state at equally spaced orbit phases. */
export function sampleCR3BPOrbit(reference, sampleCount = 720, options = {}) {
  if (!reference || !Array.isArray(reference.initialState) || !finite(reference.periodTU) || reference.periodTU <= 0) {
    throw new TypeError('A CR3BP reference orbit with initialState and periodTU is required.');
  }
  if (!Number.isInteger(sampleCount) || sampleCount < 32 || sampleCount > 10000) {
    throw new RangeError('sampleCount must be an integer from 32 to 10000.');
  }
  const points = [reference.initialState.slice()];
  let state = reference.initialState.slice();
  let totalSteps = 0;
  const baseOptions = { ...options, maxStep: options.maxStep ?? 0.006 };
  for (let i = 1; i <= sampleCount; i++) {
    const result = propagateCR3BP(state, reference.periodTU / sampleCount, baseOptions);
    state = result.state;
    totalSteps += result.steps;
    points.push(state);
  }
  const mu = options.mu ?? MU;
  const distances = points.map((p) => Math.hypot(p[0] - (1 - mu), p[1], p[2]) * LU_KM);
  const initialJacobi = jacobiConstant(reference.initialState, mu);
  const jacobiDrift = Math.max(...points.map((p) => Math.abs(jacobiConstant(p, mu) - initialJacobi)));
  const closureError = Math.hypot(...state.map((v, i) => v - reference.initialState[i]));
  const timeDays = reference.periodTU * TU_S / DAY_S;
  return {
    id: reference.id,
    points,
    periodDays: timeDays,
    minMoonRangeKm: Math.min(...distances),
    maxMoonRangeKm: Math.max(...distances),
    jacobiConstant: initialJacobi,
    jacobiDrift,
    closureError,
    integrationSteps: totalSteps,
    timeUnitDays: TU_S / DAY_S,
    distanceUnitKm: LU_KM,
  };
}

export function jacobiConstant(state, mu = MU) {
  if (!Array.isArray(state) || state.length !== 6 || !state.every(finite)) throw new TypeError('State must contain six finite values.');
  const [x, y, z, vx, vy, vz] = state;
  const r1 = Math.hypot(x + mu, y, z);
  const r2 = Math.hypot(x - 1 + mu, y, z);
  if (r1 < 1e-9 || r2 < 1e-9) throw new RangeError('Jacobi constant is undefined at a primary singularity.');
  return x * x + y * y + 2 * (1 - mu) / r1 + 2 * mu / r2 - (vx * vx + vy * vy + vz * vz);
}

/** Locate a collinear Lagrange point in the normalized rotating frame. */
export function solveCollinearLibrationPoint(point = 'L2', mu = MU) {
  if (!['L1', 'L2', 'L3'].includes(point)) throw new RangeError('point must be L1, L2 or L3.');
  const f = (x) => x - (1 - mu) * (x + mu) / Math.pow(Math.abs(x + mu), 3) - mu * (x - 1 + mu) / Math.pow(Math.abs(x - 1 + mu), 3);
  let low, high;
  if (point === 'L1') { low = -mu + 1e-5; high = 1 - mu - 1e-5; }
  else if (point === 'L2') { low = 1 - mu + 1e-5; high = 2; }
  else { low = -2; high = -mu - 1e-5; }
  // Ensure a sign-changing bracket before bisection.
  let fl = f(low), fh = f(high);
  for (let i = 0; i < 32 && fl * fh > 0; i++) {
    if (point === 'L3') low *= 2; else high = 1 - mu + (high - (1 - mu)) * 2;
    fl = f(low); fh = f(high);
  }
  if (fl * fh > 0) throw new Error(`Could not bracket ${point}.`);
  for (let i = 0; i < 100; i++) {
    const mid = (low + high) / 2;
    const fm = f(mid);
    if (Math.abs(fm) < 1e-14 || high - low < 1e-14) {
      return { point, x: mid, distanceFromMoonKm: (mid - (1 - mu)) * LU_KM };
    }
    if (fl * fm <= 0) { high = mid; fh = fm; } else { low = mid; fl = fm; }
  }
  const x = (low + high) / 2;
  return { point, x, distanceFromMoonKm: (x - (1 - mu)) * LU_KM };
}

export function getCislunarOrbit(referenceId, sampleCount = 720) {
  const reference = CR3BP_REFERENCE_ORBITS[referenceId];
  if (!reference) return null;
  return sampleCR3BPOrbit(reference, sampleCount);
}

const summaryCache = new Map();
export function cislunarOrbitSummary(referenceId) {
  if (summaryCache.has(referenceId)) return summaryCache.get(referenceId);
  const reference = CR3BP_REFERENCE_ORBITS[referenceId];
  if (!reference) return null;
  const result = sampleCR3BPOrbit(reference, 360);
  const l2Point = solveCollinearLibrationPoint('L2');
  const summary = {
    name: reference.name,
    family: reference.family,
    periodDays: result.periodDays,
    periluneKm: result.minMoonRangeKm,
    apoluneKm: result.maxMoonRangeKm,
    jacobi: result.jacobiConstant,
    closureError: result.closureError,
    jacobiDrift: result.jacobiDrift,
    l2DistanceFromMoonKm: l2Point.distanceFromMoonKm,
    nasaGatewayValidation: referenceId === 'nrho' ? Object.freeze({
      periluneWithinPublishedRange: result.minMoonRangeKm >= NASA_GATEWAY_NRHO_REFERENCE.periluneRadiusRangeKm[0] && result.minMoonRangeKm <= NASA_GATEWAY_NRHO_REFERENCE.periluneRadiusRangeKm[1],
      apoluneWithinPublishedRange: result.maxMoonRangeKm >= NASA_GATEWAY_NRHO_REFERENCE.apoluneRadiusRangeKm[0] && result.maxMoonRangeKm <= NASA_GATEWAY_NRHO_REFERENCE.apoluneRadiusRangeKm[1],
      periodDifferenceDays: result.periodDays - NASA_GATEWAY_NRHO_REFERENCE.averagePeriodDays,
      apoluneDifferenceKm: result.maxMoonRangeKm - NASA_GATEWAY_NRHO_REFERENCE.apoluneRadiusKm,
    }) : null,
  };
  summaryCache.set(referenceId, summary);
  return summary;
}

export const CR3BP_MODEL_SCOPE = Object.freeze({
  included: ['Earth and Moon point-mass gravity', 'circular primary motion', 'barycentric rotating frame', 'Coriolis and centrifugal terms', 'adaptive Dormand-Prince 5(4) propagation', 'Jacobi integral monitoring'],
  excluded: ['solar third-body perturbations', 'Earth/Moon non-spherical gravity', 'solar radiation pressure', 'maneuver execution and orbit determination', 'high-fidelity DE440/SPICE ephemeris propagation'],
});
