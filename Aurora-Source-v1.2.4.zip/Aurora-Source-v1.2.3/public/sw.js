/* Aurora offline shell. Never cache API responses or user-specific room state. */
const CACHE = 'aurora-shell-v5';
const SHELL = [
  '/', '/index.html', '/manifest.webmanifest', '/icons/aurora.svg', '/icons/aurora-192.png', '/icons/aurora-512.png',
  '/css/game.css', '/vendor/three.module.min.js',
  '/assets/kenney-ui/Font/Kenney%20Future%20Narrow.ttf',
  '/assets/kenney-ui/aurora-themed/blue-button_square_header_large_rectangle.png',
  '/assets/kenney-ui/aurora-themed/yellow-button_square_header_large_rectangle.png',
  '/assets/kenney-ui/aurora-themed/green-button_square_header_large_rectangle.png',
  '/assets/kenney-ui/aurora-themed/blue-button_square_header_large_square.png',
  '/assets/kenney-ui/aurora-themed/green-button_square_header_large_square.png',
  '/assets/kenney-ui/aurora-themed/blue-bar_round_gloss_small_square.png',
  '/assets/kenney-ui/aurora-themed/yellow-bar_round_gloss_small_square.png',
  '/assets/kenney-ui/aurora-themed/red-bar_round_gloss_small_square.png',
  '/js/data.js', '/js/engine.js', '/js/fx.js', '/js/main.js',
  '/js/net.js', '/js/orbital.js', '/js/cr3bp.js', '/js/scene3d.js', '/js/views.js'
];
self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key.startsWith('aurora-shell-') && key !== CACHE).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin || url.pathname.startsWith('/api/')) return;
  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).then((response) => {
      if (response && response.ok) { const copy = response.clone(); caches.open(CACHE).then((cache) => cache.put('/', copy)); }
      return response;
    }).catch(async () => (await caches.match('/')) || (await caches.match('/index.html'))));
    return;
  }
  event.respondWith(caches.match(request).then((cached) => {
    if (cached) return cached;
    return fetch(request).then((response) => {
      if (response && response.ok && response.type === 'basic') {
        const copy = response.clone(); caches.open(CACHE).then((cache) => cache.put(request, copy));
      }
      return response;
    });
  }));
});
