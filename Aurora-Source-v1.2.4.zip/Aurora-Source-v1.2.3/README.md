# Aurora — Space Mission Design

**Design a mission. Engineer the spacecraft. Launch it. Operate it. Learn from every trade-off.**

Aurora is an educational browser game for the 2026 NASA Space Apps Challenge brief, *Space Mission Design Game*. Players choose a science objective, assemble a spacecraft, balance mass/power/data/budget, select a launcher and orbit, plan ground communications, operate the mission through events, and review a debrief that explains the result.

Aurora is an educational browser game maintained as a self-contained project. No Hill Climb Racing code, assets, or proprietary binaries are included in this repository. The Hill Climb Racing APK was discussed only as a reverse-engineering reference for general game-architecture concepts.

> **Scientific scope:** Aurora is an educational trade-study game, not flight software or an engineering certification tool. Part masses, costs, power, downlink, event probabilities, and scoring are simplified game-balance values. Lunar NRHO and Earth–Moon L2 scenes now use a numerically integrated Earth–Moon Circular Restricted Three-Body Problem (CR3BP) model; other orbit families use Keplerian two-body approximations or explicitly schematic transfers. CR3BP still omits solar perturbations, gravity harmonics, solar radiation pressure, maneuvers and high-fidelity SPICE ephemerides. Do not use outputs to plan a real mission.

## Current game flow

| Phase | What the player does |
|---|---|
| Objective | Choose one of five mission scenarios, a study level and a play mode. |
| Spacecraft design | Select the bus, solar array, battery, communications, computer, attitude-control and propulsion systems; choose science instruments. Live gauges show mass, power, budget, data and Δv. |
| Launch and orbit | Choose an orbit and launcher, then follow the launch sequence. |
| Mission operations | Choose a ground network, run the timeline and respond to engineering/science/operations emergencies. |
| Debrief | Review the result, objective checks, score breakdown and design suggestions; export a text report. |

## Included capabilities

- Procedural Three.js 3D scenes with a CSS fallback when WebGL 2 is unavailable.
- Five scenarios: CubeSat Classroom, Wildfire Watch, Lunar Relay, Asteroid Scout and Red Planet Weather.
- Five modes: solo, local co-op, online co-op, versus challenge and sandbox.
- A deterministic mission engine shared by browser and Cloudflare Worker.
- Kepler equation solver and two-body orbit propagation for closed conics; adaptive Dormand–Prince 5(4) integration for the Earth–Moon CR3BP NRHO and L2 halo reference paths; Lagrange L2 point solution and Jacobi-constant monitoring.
- Server-replayed leaderboard scores; the client-supplied score is never trusted.
- Online crew rooms using Cloudflare Durable Objects and WebSockets.
- Keyboard support, screen-reader live announcements, reduced-motion support and synthesized sound controls.
- Local draft autosave with one-time migration of legacy browser preferences.
- Installable PWA shell and offline caching for the game assets. Leaderboards and online rooms still require the configured backend.

## Run locally

Requirements: Node.js 20 or newer.

```bash
npm install
npm test
npm run dev
```

Open the local URL printed by Wrangler. The game can also run as a static site by serving the `public/` directory; mission design and simulation remain playable, while online rooms and the leaderboard are disabled without the Worker backend. On a phone, open the hosted URL in landscape orientation; after the first visit, the service worker caches the game shell for offline use. See [START-HERE-ARABIC.md](START-HERE-ARABIC.md) for the phone-first handoff, [Cloudflare deployment guide](docs/CLOUDFLARE-DEPLOY-AR.md) for D1/Worker setup, and [Competition readiness](docs/COMPETITION-READINESS.md) for the two important eligibility gates.

### Cloudflare backend setup

The repository is intentionally configured with a local placeholder D1 database ID so Aurora cannot accidentally write to an unrelated remote database.

1. Install dependencies with `npm install`.
2. For the first GitHub Actions deployment, add `CLOUDFLARE_API_TOKEN` with D1 Write and Workers Admin at the Workers product scope (needed only to create a new Worker), plus `CLOUDFLARE_ACCOUNT_ID`, as repository Actions secrets. After the Worker exists, replace the token with D1 Write + Workers Editor scoped to that Worker.
3. Run **Deploy Aurora to Cloudflare**. The workflow provisions or reuses the named D1 database, patches its UUID into the ephemeral CI config, applies migrations and deploys the Worker.
4. After the first deployment, rerun the workflow with `worker_url` set to the public `workers.dev` URL to run remote smoke tests.

For manual CLI deployment, authenticate with `npx wrangler login`, create the DB using `npx wrangler d1 create aurora-space-mission`, copy its UUID into `wrangler.jsonc`, apply migrations, then deploy.

For local development, `npm run db:migrate:local` creates the local D1 schema. Cloudflare account resources are not bundled and must be configured by the deploying team.

## Validation commands

```bash
npm test          # deterministic game-engine unit tests
npm run check     # Wrangler Worker bundle dry run (requires dependencies)
npm run test:smoke # API/room integration tests against a running Wrangler dev server
```

The smoke test expects the local Worker on `http://127.0.0.1:8787` and a working local D1 database.

## Architecture

```text
public/
  index.html                 app shell and metadata
  manifest.webmanifest       installable PWA metadata
  sw.js                      offline asset cache (never caches /api)
  css/game.css               fixed 1440×810 game stage and responsive scaling
  js/data.js                 mission, component, orbit, launcher, ground and event data
  js/engine.js               deterministic rules, evaluation, simulation and scoring
  js/orbital.js              Kepler equation solver and two-body orbit-state utilities
  js/cr3bp.js                Earth–Moon CR3BP constants, integrator, reference orbits and diagnostics
  js/views.js                screen templates and accessible controls
  js/main.js                 app state, autosave, transitions, game loop and room sync
  js/scene3d.js              procedural Three.js scenes
  js/net.js                  API and WebSocket client
  js/fx.js                   synthesized sound effects
  vendor/                    Three.js r170 (MIT)
src/worker.js                Cloudflare Worker API and MissionRoom Durable Object
migrations/                  D1 schema
 test/                       engine and API smoke tests
docs/screenshots/            intentionally empty until genuine Aurora captures are made
```

## Scientific data and validation

Aurora bundles selected published constants and reference values from NASA Gateway trajectory documentation and JPL DE440. The NRHO is numerically integrated and its period/perilune/apolune are checked against the NASA Gateway reference envelope. The model does not download a NASA SPK trajectory, connect to a live NASA API, or reproduce an operational Gateway ephemeris. See [PHYSICS-MODEL.md](docs/PHYSICS-MODEL.md), [DATA-PROVENANCE.md](docs/DATA-PROVENANCE.md) and [VALIDATION-REPORT.md](docs/VALIDATION-REPORT.md) for equations, source links, reference-state attribution, measured diagnostics and outstanding release gates.

`npm test` now includes eight dedicated CR3BP tests, in addition to the mission, Kepler and asset tests. `npm run test:smoke` exercises score validation, D1 leaderboard persistence and four-player Durable Object rooms when a local Wrangler/D1 environment is running. After deployment, enter the public Worker URL in the `worker_url` field of the GitHub Actions workflow to run the same smoke test against the live D1 and Durable Object rooms. See [Android real-device QA](docs/ANDROID-REAL-DEVICE-QA-AR.md) and [NASA resource verification](docs/NASA-RESOURCES-VERIFY-AR.md).

## Security and operational notes

- The Worker recomputes submitted scores from the normalized design, seed and decisions before writing a leaderboard row.
- Versus challenge seeds are derived on the server from the shared challenge code, mission and level.
- Only generated callsigns are accepted; free-text names are rejected.
- Online room state is transient and stored in a Durable Object while the room is active. The Commander is authoritative for mission state; crew edits and votes are relayed.
- Open leaderboards use a client-selected seed in the current implementation. This is a known fairness limitation: determined players can try multiple seeds offline. Versus mode avoids that limitation by deriving the seed server-side.
- Browser storage is local to the device. The app does not create user accounts.

## Screenshots and test evidence

This source package does not include screenshots. Capture genuine Aurora screens from the deployed build before final submission; recommended shots are title, mission selection, spacecraft builder, launch/NRHO scene, mission operations and debrief.

## Credits and disclosure

Aurora is an independent educational project and is not affiliated with, sponsored by, or endorsed by NASA.

The Kenney Sci-fi UI Pack 2.0 is bundled under CC0; its license and asset sources are preserved in `public/assets/kenney-ui/`. The game has no generative-AI feature at runtime; the crew uses fixed rules.

Three.js is distributed under MIT. Orbitron and Chakra Petch are loaded from Google Fonts under their respective licenses. The UI's graphics, 3D planets, craft, orbit views and sounds are procedurally generated at runtime by the code; there are no third-party Hill Climb Racing assets in this project.

## License

MIT. See [LICENSE](LICENSE). Retain the copyright and permission notice when redistributing this software.
