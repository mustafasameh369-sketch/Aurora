# Aurora implementation notes

This revision consolidates the application under the Aurora project identity and adds several functional improvements.

## Implemented

- Rebranded the app shell, title screen, reports, package metadata, Cloudflare Worker name, D1 database name, CI and deploy workflow to Aurora.
- Updated the project license notice and retained separate license files for bundled third-party assets and libraries.
- Added a reusable Kepler equation solver, elliptic position calculation and two-body state propagation in `public/js/orbital.js`.
- Updated closed-orbit 3D animation to use Keplerian timing. NRHO/L2/flyby paths remain visual approximations and are explicitly described as such.
- Added installable PWA metadata, Aurora icons and a service worker that caches the game shell for offline play while excluding `/api/` responses.
- Added automatic local draft saving and a Resume Saved Design action. Legacy local preferences are migrated to the `aurora.*` namespace.
- Improved invalid-emergency handling and aligned room-code validation with the server's restricted code alphabet.
- Expanded deterministic, orbital-math, input-normalization and PWA metadata tests.
- Set the D1 database ID to a local placeholder so deployments cannot accidentally use an unrelated remote database.

## Validation

- `npm test`: 22 tests passed.
- `node --check` on all JavaScript modules, the service worker, Worker and tests: passed.
- PWA manifest icon/path checks: passed.
- A full Wrangler bundle/deploy and online-room smoke test were not completed in this environment because `npm ci` could not finish dependency installation before timeout. Run those checks after installing dependencies locally.

## Still needs project-specific assets and deployment configuration

- The supplied archive did not include Aurora's final art pack or reference videos. The existing generated 3D/CSS visuals remain as placeholders until the approved artwork, animation references and UI direction are supplied.
- Replace the all-zero `database_id` in `wrangler.jsonc` with the new ID returned by `npx wrangler d1 create aurora-space-mission` before remote migration or deployment.
- Add the deploying team's Cloudflare API token and account ID as GitHub Actions secrets before enabling the deploy workflow.
- The mission model remains an educational trade-study approximation. Halo/three-body dynamics, atmospheric drag, perturbations, launch vehicle performance and high-fidelity comm link budgets are not yet modeled as mission-grade engineering systems.
- No Hill Climb Racing proprietary code, graphics, or binary assets were copied into Aurora. Its APK is not required to build or run Aurora.


## Final UI asset integration

- Integrated the supplied Kenney UI Pack: Sci-fi 2.0 (CC0), preserving its original PNG assets, fonts and license in `public/assets/kenney-ui/`.
- Generated a restrained dark Aurora palette from selected Kenney button frames and status-bar sprites; applied these to action buttons, icon buttons, component tiles and engineering gauges.
- Added a local Kenney Future Narrow font for compact HUD labels and adjusted Content Security Policy to permit bundled local fonts.
- Updated the service-worker cache revision and precache list for the newly used sprites and font.
- Added `START-HERE-ARABIC.md` for phone-first setup and `KENNEY-ASSETS.md` for asset provenance.
- Updated the package version to 1.1.0.


## Aurora 1.2.0 — cislunar physics and provenance hardening

- Added `public/js/cr3bp.js`: Earth–Moon Circular Restricted Three-Body Problem, JPL DE440 Earth/Moon GM constants, normalized coordinates, adaptive Dormand–Prince 5(4) integration, Jacobi invariant monitoring, L1/L2/L3 collinear point solver, and sampled periodic reference trajectories.
- Replaced the lunar NRHO and L2 3D paths with numerically propagated CR3BP trajectories; spacecraft movement follows the numerical trajectory tangent. The L2 equilibrium marker is solved numerically. The 3D scene compression is explicitly labeled and does not alter trajectory computation.
- Added NASA Gateway 9:2 NRHO reference metrics as a benchmark; the computed NRHO perilune lies within NASA's published range. Added source-attributed reference initial states for the NRHO and a separate L2 southern halo example.
- Added `docs/PHYSICS-MODEL.md` and `docs/DATA-PROVENANCE.md`, documenting constants, reference-state sources, validation outputs, third-party assets and limitations. No live NASA API, SPK kernel or flight ephemeris is claimed.
- Added eight CR3BP tests and deployment/mobile shell guard tests; `npm test` currently reports 36 passing tests.
- Added the CR3BP module to the PWA offline cache and bumped the cache to `aurora-shell-v4`.
- Expanded API smoke coverage to four distinct crew roles and a rejected fifth player. Added explicit 503 responses when D1 or Durable Object bindings are missing.
- Added a Cloudflare deployment preflight so deployment/migration commands stop while the D1 ID is still the all-zero placeholder.
- Kept `docs/screenshots` free of unverified captures. Genuine screenshots still need to be taken from a running build.

## Validation status for this revision

- `node --test test/*.test.js`: 36 passed, 0 failed.
- `node --check` on public, Worker, test and script JavaScript: passed.
- SQLite execution of the D1 migration (create table, insert and select): passed. Local/remote Wrangler Worker, D1 binding and real four-browser Durable Object integration: not executed because Wrangler dependencies could not be installed before timeout and Cloudflare account credentials are not configured. The four-seat smoke test is prepared but not claimed as run.
- Physical Android browser/device QA: not executed; the codebase includes responsive landscape scaling and an orientation prompt, but that is not a substitute for testing on the team's actual phone.
- Real Aurora screenshots: not included; capture them from a running build before submission.

## 1.2.1 — deployment verification handoff

- Added an optional post-deploy remote smoke-test input to the Cloudflare GitHub Actions workflow. Supplying the public Worker URL runs the existing API + leaderboard + four-seat Durable Object/WebSocket smoke test after deployment.
- Added a dedicated `test:smoke:remote` npm script for repeatable remote checks.
- Clarified that the remote deployment, real four-device room QA, and physical Android QA are external release gates and must not be reported as completed until their evidence exists.


## 1.2.2 — D1 bootstrap and challenge resource citation clarification
- Added automated Cloudflare D1 provisioning/reuse from GitHub Actions through the official D1 REST API, and wired its UUID into the ephemeral Wrangler configuration. Requires the team's account ID and an API token stored only in GitHub Secrets.
- Added unit tests for D1 database selection and UUID binding updates.
- Corrected the status/attribution of NASA Space Apps discussion #1924: it is a Navigator answer, not a GO Team answer.
- Identified the JPL CML resource in a local-event reproduction of the challenge resource list and linked it to the JPL Dataverse record `hdl:2014/44299`.
- Added the JPL CML framework citation in the in-game Help/Credits screen and documented the adaptation in `docs/DATA-PROVENANCE.md`.
- Kept Global Awards qualification explicitly provisional until the organizer confirms that the JPL Dataverse CML framework record satisfies the wording “NASA data source”.


## 1.2.3 — deployment permissions and NASA resource verification
- Corrected Cloudflare API-token guidance to use current Workers product roles: Workers Admin for first-time Worker creation, Workers Editor for subsequent deployments, and D1 Write for D1 provisioning/migrations.
- Verified the CML link directly from the Space Mission Design Game local-event resource listing and the JPL Dataverse record; retained the note that NASA GO Team interpretation must be confirmed against the official Resources tab.
- Updated Arabic setup and validation handoff to distinguish the automated four-client WebSocket CI test from a real four-device team test and to avoid claiming physical Android screenshots.
