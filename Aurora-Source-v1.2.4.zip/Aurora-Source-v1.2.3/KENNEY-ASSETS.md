# Kenney UI Pack integration

Aurora includes the Kenney UI Pack: Sci-fi (2.0), distributed under Creative Commons Zero (CC0).

- Original assets are preserved in `public/assets/kenney-ui/PNG/`.
- Original fonts are preserved in `public/assets/kenney-ui/Font/`.
- Aurora-tinted variants used by the interface are in `public/assets/kenney-ui/aurora-themed/`.
- The original license is included at `public/assets/kenney-ui/License.txt`.

The CC0 notice states that the content may be used in personal, educational, and commercial projects. Crediting Kenney is optional; Aurora credits Kenney as a courtesy.
