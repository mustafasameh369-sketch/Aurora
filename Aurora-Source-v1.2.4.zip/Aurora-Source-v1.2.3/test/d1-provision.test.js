import test from 'node:test';
import assert from 'node:assert/strict';
import { findNamedDatabase, updateWranglerDatabaseId } from '../scripts/d1-provision-utils.mjs';

const uuid = '12345678-1234-4abc-8def-1234567890ab';

test('D1 provisioning finds an existing named database in Cloudflare list response', () => {
  const result = findNamedDatabase({ success: true, result: [
    { name: 'other-db', uuid: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa' },
    { name: 'aurora-space-mission', uuid }
  ] }, 'aurora-space-mission');
  assert.equal(result.uuid, uuid);
});

test('D1 provisioning writes only the matching database binding ID', () => {
  const config = `{"d1_databases":[{"binding":"DB","database_name":"aurora-space-mission","database_id":"00000000-0000-0000-0000-000000000000","migrations_dir":"migrations"}]}`;
  const updated = updateWranglerDatabaseId(config, 'aurora-space-mission', uuid);
  assert.match(updated, new RegExp(`"database_id":"${uuid}"`));
  assert.doesNotMatch(updated, /00000000-0000-0000-0000-000000000000/);
});

test('D1 provisioning rejects a missing binding or invalid UUID', () => {
  assert.throws(() => updateWranglerDatabaseId('{"d1_databases":[]}', 'aurora-space-mission', uuid), /Expected exactly one D1 binding/);
  assert.throws(() => updateWranglerDatabaseId('{"database_name":"aurora-space-mission","database_id":"x"}', 'aurora-space-mission', 'x'), /invalid D1 database UUID/);
});
