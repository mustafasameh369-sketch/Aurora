import test from 'node:test';
import assert from 'node:assert/strict';
import {
  EARTH_MOON,
  CR3BP_REFERENCE_ORBITS,
  NASA_GATEWAY_NRHO_REFERENCE,
  CR3BP_MODEL_SCOPE,
  cr3bpDerivative,
  jacobiConstant,
  propagateCR3BP,
  sampleCR3BPOrbit,
  solveCollinearLibrationPoint,
  cislunarOrbitSummary,
} from '../public/js/cr3bp.js';

const closeTo = (actual, expected, tolerance) => assert.ok(Math.abs(actual - expected) <= tolerance, `${actual} not within ${tolerance} of ${expected}`);

test('Earth–Moon normalized constants use the published JPL DE440 GMs', () => {
  closeTo(EARTH_MOON.mu, 0.012150584394709708, 1e-14);
  closeTo(EARTH_MOON.timeUnitSeconds, 375190.2619, 0.01);
  assert.equal(NASA_GATEWAY_NRHO_REFERENCE.averagePeriodDays, 6.56);
});

test('CR3BP derivative and Jacobi integral return finite states', () => {
  const state = CR3BP_REFERENCE_ORBITS.nrho.initialState;
  const derivative = cr3bpDerivative(state);
  assert.equal(derivative.length, 6);
  assert.deepEqual(derivative.slice(0, 3), state.slice(3, 6));
  assert.ok(Number.isFinite(jacobiConstant(state)));
  assert.throws(() => cr3bpDerivative([1, 2]), /six finite/);
  assert.throws(() => cr3bpDerivative(state, 0.8), /mass parameter/);
});

test('Earth–Moon L2 collinear point is solved numerically', () => {
  const l2 = solveCollinearLibrationPoint('L2');
  assert.ok(l2.x > 1 - EARTH_MOON.mu);
  closeTo(l2.distanceFromMoonKm, 64515, 2);
  assert.throws(() => solveCollinearLibrationPoint('L4'), /L1, L2 or L3/);
});

test('adaptive propagation preserves the Jacobi integral over the NRHO reference period', () => {
  const ref = CR3BP_REFERENCE_ORBITS.nrho;
  const result = propagateCR3BP(ref.initialState, ref.periodTU);
  assert.equal(result.state.length, 6);
  assert.ok(result.steps > 0);
  assert.ok(result.jacobiDrift === undefined || Number.isFinite(result.jacobi));
  const closure = Math.hypot(...result.state.map((v, i) => v - ref.initialState[i]));
  assert.ok(closure < 2e-6, `periodic closure error ${closure}`);
  closeTo(result.jacobi, jacobiConstant(ref.initialState), 1e-8);
});

test('NRHO integration is consistent with NASA Gateway reference orbit envelope', () => {
  const result = sampleCR3BPOrbit(CR3BP_REFERENCE_ORBITS.nrho, 240);
  assert.ok(result.minMoonRangeKm >= 3196 && result.minMoonRangeKm <= 3557, `perilune ${result.minMoonRangeKm}`);
  closeTo(result.periodDays, 6.56, 0.02);
  assert.ok(result.maxMoonRangeKm >= 70005 && result.maxMoonRangeKm <= 71849, `apolune ${result.maxMoonRangeKm}`);
  assert.ok(result.jacobiDrift < 1e-8);
  assert.ok(result.closureError < 2e-6);
  const summary = cislunarOrbitSummary('nrho');
  assert.equal(summary.nasaGatewayValidation.periluneWithinPublishedRange, true);
  assert.equal(summary.nasaGatewayValidation.apoluneWithinPublishedRange, true);
});

test('southern L2 halo example integrates as a separate periodic family', () => {
  const result = sampleCR3BPOrbit(CR3BP_REFERENCE_ORBITS.l2, 240);
  assert.ok(result.periodDays > 12 && result.periodDays < 13);
  assert.ok(result.minMoonRangeKm > 25000 && result.maxMoonRangeKm > 80000);
  assert.ok(result.jacobiDrift < 1e-8);
  assert.ok(result.closureError < 2e-6);
});

test('CR3BP model clearly declares the physical effects not included', () => {
  assert.ok(CR3BP_MODEL_SCOPE.included.includes('adaptive Dormand-Prince 5(4) propagation'));
  assert.ok(CR3BP_MODEL_SCOPE.excluded.includes('solar third-body perturbations'));
  assert.ok(CR3BP_MODEL_SCOPE.excluded.includes('high-fidelity DE440/SPICE ephemeris propagation'));
});

test('integrator rejects invalid duration and options', () => {
  const state = CR3BP_REFERENCE_ORBITS.nrho.initialState;
  assert.throws(() => propagateCR3BP(state, -1), /non-negative/);
  assert.throws(() => propagateCR3BP(state, 0.1, { relTol: 0 }), /Invalid integration options/);
});
