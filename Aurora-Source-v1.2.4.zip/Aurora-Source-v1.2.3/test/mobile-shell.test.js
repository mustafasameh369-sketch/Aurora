import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

test('PWA requests landscape mode and supplies a portrait orientation hint', () => {
  const manifest = JSON.parse(fs.readFileSync(path.join(root, 'public/manifest.webmanifest'), 'utf8'));
  const css = fs.readFileSync(path.join(root, 'public/css/game.css'), 'utf8');
  assert.equal(manifest.orientation, 'landscape');
  assert.match(css, /@media \(orientation: portrait\) and \(max-width: 700px\)/);
  assert.match(css, /#rotate \{ display: flex/);
});

test('game stage scales to the smaller phone viewport dimension', () => {
  const main = fs.readFileSync(path.join(root, 'public/js/main.js'), 'utf8');
  assert.match(main, /Math\.min\(window\.innerWidth\s*\/\s*1440,\s*window\.innerHeight\s*\/\s*810\)/);
  assert.match(main, /stage\.style\.transform\s*=\s*`scale\(\$\{s\}\)`/);
});
