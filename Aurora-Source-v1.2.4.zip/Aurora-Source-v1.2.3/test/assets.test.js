import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const publicDir = path.join(root, 'public');

test('all Kenney UI assets referenced by CSS are bundled', () => {
  const css = fs.readFileSync(path.join(publicDir, 'css/game.css'), 'utf8');
  const refs = [...css.matchAll(/url\(['\"]?([^'\")]+)['\"]?\)/g)]
    .map((m) => m[1]).filter((x) => x.startsWith('/assets/'));
  assert.ok(refs.length >= 8, 'expected the UI pack to be used in the interface');
  for (const ref of refs) {
    const disk = path.join(publicDir, decodeURIComponent(ref.replace(/^\//, '')));
    assert.ok(fs.existsSync(disk), `missing referenced asset: ${ref}`);
  }
});

test('Kenney UI pack attribution and offline cache are present', () => {
  const license = fs.readFileSync(path.join(publicDir, 'assets/kenney-ui/License.txt'), 'utf8');
  const sw = fs.readFileSync(path.join(publicDir, 'sw.js'), 'utf8');
  assert.match(license, /Creative Commons Zero|CC0/i);
  assert.match(sw, /aurora-shell-v5/);
  assert.match(sw, /blue-button_square_header_large_rectangle\.png/);
  assert.match(sw, /\/js\/cr3bp\.js/);
  assert.ok(fs.existsSync(path.join(publicDir, 'assets/kenney-ui/Font/Kenney Future Narrow.ttf')));
});
