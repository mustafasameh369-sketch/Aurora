import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

test('Cloudflare deployment is blocked while the D1 id is a placeholder', () => {
  const result = spawnSync(process.execPath, ['scripts/preflight-cloudflare.mjs'], { cwd: root, encoding: 'utf8' });
  assert.equal(result.status, 1);
  assert.match(result.stderr, /database_id is still a placeholder/);
});

test('Worker reports D1 schema health rather than just the binding flag', () => {
  const worker = fs.readFileSync(path.join(root, 'src/worker.js'), 'utf8');
  assert.match(worker, /SELECT COUNT\(\*\) AS count FROM scores/);
  assert.match(worker, /Online rooms are not configured/);
  assert.match(worker, /Leaderboard database is not configured/);
});
