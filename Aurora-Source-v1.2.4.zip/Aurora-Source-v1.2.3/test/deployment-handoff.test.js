import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const workflow = readFileSync(new URL('../.github/workflows/deploy.yml', import.meta.url), 'utf8');
const guide = readFileSync(new URL('../docs/CLOUDFLARE-DEPLOY-AR.md', import.meta.url), 'utf8');
const phoneQA = readFileSync(new URL('../docs/ANDROID-REAL-DEVICE-QA-AR.md', import.meta.url), 'utf8');
const nasaGate = readFileSync(new URL('../docs/NASA-RESOURCES-VERIFY-AR.md', import.meta.url), 'utf8');
const views = readFileSync(new URL('../public/js/views.js', import.meta.url), 'utf8');
const sw = readFileSync(new URL('../public/sw.js', import.meta.url), 'utf8');

test('manual Cloudflare workflow exposes a public URL input for post-deploy smoke testing', () => {
  assert.match(workflow, /worker_url:/);
  assert.match(workflow, /node scripts\/ensure-d1\.mjs/);
  assert.match(workflow, /node test\/api-smoke\.mjs/);
  assert.match(workflow, /CLOUDFLARE_API_TOKEN/);
  assert.match(workflow, /CLOUDFLARE_ACCOUNT_ID/);
});

test('handoff docs distinguish remote setup, physical Android QA and NASA resource eligibility', () => {
  assert.match(guide, /worker_url/);
  assert.match(phoneQA, /هاتف Android حقيقي/);
  assert.match(nasaGate, /JPL Dataverse dataset/);
  assert.match(nasaGate, /مرشح قوي/);
  assert.match(nasaGate, /ليس بمقدورنا ضمان ذلك/);
});

test('JPL CML challenge resource is credited in-game and offline cache is versioned', () => {
  assert.match(views, /dataverse\.jpl\.nasa\.gov\/dataset\.xhtml\?persistentId=hdl:2014\/44299/);
  assert.match(views, /Concept Maturity Levels/);
  assert.match(sw, /aurora-shell-v5/);
});
